# Project 3 Prep

**For tessellating pluses, one of the hardest parts is figuring out where to place each plus/how to easily place plus on screen in an algorithmic way.
If you did not implement tesselation, please try to come up with an algorithmic approach to place pluses on the screen. This means a strategy, pseudocode, or even actual code! 
Consider the `HexWorld` implementation provided near the end of the lab (within the lab video). Note that `HexWorld` was the lab assignment from a previous semester (in which students drew hexagons instead of pluses). 
How did your proposed implementation/algorithm differ from the given one (aside from obviously hexagons versus pluses) ? What lessons can be learned from it?**

Answer: To tessellate the pluses, I would want to randomize the positions they start in. This means that throughout the world, I'd want a plus to "spawn" anywhere. To do this, I'd have to use the randomizer and then everytime a new plus is drawn, I would have to call on the randomizer in order to randomize the location of the plus and even maybe the size of the plus. In regards to 
comparisons, there were more factors I had to take in than I initially considered, including how pluses that spawn next to each other could still be a "complete" plus yet still random. In order to do this, in the spec, they used the reflective property in a hexagon's shape in order to figure out where the hexagon starts and ends so that hexagons could be placed adjacent to each other.

-----

**Can you think of an analogy between the process of tessellating pluses and randomly generating a world using rooms and hallways?
What is the plus and what is the tesselation on the Project 3 side?**

Answer: Tessellating pluses is like learning how to walk, while randomly generating a world using rooms and hallways is learning how to jump, run, skip, and even do cartwheels.
The plus is a step and the tessellation is the act of walking itself. It combines the tiny "pluses" together to create one bigger action. 

-----
**If you were to start working on world generation, what kind of method would you think of writing first? 
Think back to the lab and the process used to eventually get to tessellating pluses.**

Answer: I would think of how to create the different shapes I'd want in the world first. This would mean shapes of the "rooms" (triangles, rectangles, circles, squares, etc.)  After that,
I would want to think of how to create a hallway next, which would be the spaces between the rooms. Since I have the rooms set up already, I can just randomly 
place rooms and at set distances and set the distance between rooms as hallways, but there are many other strategies available.

-----
**What distinguishes a hallway from a room? How are they similar?**

Answer: A hallway is the area between non-adjacent rooms while rooms are areas that can help "separate" hallways. Hallways can also connect the rooms together. 
They are similar in that they both take on certain recognizable shapes and allow for exploration on the user's side. 
