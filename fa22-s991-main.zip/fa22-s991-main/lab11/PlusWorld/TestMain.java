package PlusWorld;

public class TestMain {
    public static void main(String[] args) {
        PlusDrawer plus = new PlusDrawer();
        plus.drawPlus(6);
    }
}
