package PlusWorld;

public class PlusDrawer {
    private int middle;

    public void drawPlus(int size) {
        middle = 3;

        String character  = "x";
        String empty = " ";

        String characterRepeat = character.repeat(size);
        String emptyRepeat = empty.repeat(size);
        String middleCharacterRepeat = character.repeat((middle*size));

        for (int i = 0; i < size; i++) {
            System.out.println(emptyRepeat + characterRepeat + emptyRepeat);
        }

        for (int i = 0; i < size; i++) {
            System.out.println(middleCharacterRepeat);
        }

        for (int i = 0; i < size; i++) {
            System.out.println(emptyRepeat + characterRepeat + emptyRepeat);
        }

    }
}
