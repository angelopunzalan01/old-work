public class ArrayDeque<T> {
    private T[] arrayList = ((T[]) new Object[8]);
    private int size;
    private int startPosition;
    private int endPosition;

    private void resize() {
        if (fullAList()) {
            int firstHalfStart = arrayList.length - startPosition;
            int halfPoint = arrayList.length / 2;
            int secondHalfStart = endPosition - 1;
            T[] newAList = ((T[]) new Object[(halfPoint)]);
            if (firstHalfStart >= halfPoint) {
                System.arraycopy(arrayList, startPosition, newAList, 0, halfPoint);
            } else if (size == firstHalfStart) {
                System.arraycopy(arrayList, startPosition, newAList, 0, size);
            } else {
                System.arraycopy(arrayList, 0, newAList, firstHalfStart, size - firstHalfStart);
            }
            startPosition = 0;
            endPosition = size - 1;
            arrayList = newAList
        } else if (outOfRange()) {
            int firstHalfStart = arrayList.length - startPosition;
            int halfPoint = arrayList.length / 2;
            int secondHalfStart = endPosition - 1;
            T[] newAList = ((T[]) new Object[(halfPoint)]);
            if (firstHalfStart >= halfPoint) {
                System.arraycopy(arrayList, startPosition, newAList, 0, halfPoint);
            } else if (size == length) {
                System.arraycopy(arrayList, startPosition, newAList, 0, size);
            } else {
                System.arraycopy(arrayList, 0, newAList, firstHalfStart, size - firstHalfStart);
            }
            startPosition = 0;
            endPosition = size - 1;
            arrayList = newAList
        }
    }
    public void addFirst(T item) {
        if (fullAList()) {
            resize();
        } else {
            size += 1;
            startPosition =
        }
    }

    public boolean outOfRange() {
        if (size < (arrayList.length / 4) && size >=0) {
            return true;
        } else {
            return false;
        }
    }


    public void addLast(T item) {

    }

    public boolean emptyAList() {
        if (size == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean fullAList() {
        if (size == arrayList.length) {
            return true;
        } else {
            return false;
        }
    }
    public int size() {
        return size;
    }

    public void printDeque() {
        for (int i = 0; i < size; i += 1) {
            System.out.print(arrayList[i]);
            System.out.print(" ");
        }
    }

    public T removeFirst() {

    }

    public T removeLast() {

    }

    public T get(int index) {

    }

    public boolean equals(Object o) {

    }

    public ArrayDeque() {
        size = 0;
        startPosition = 0;
        endPosition = arrayList.length - 1
    }



}