package deque;
/* i now have a new laptop*/
public class LinkedListDeque<T> {
    private int size;
    private IntNode sentinel;
    private IntNode prev;
    private IntNode next;
    public class Deque {
        public Deque(T item, IntNode n, IntNode p) {
            item = i;
            next = n;
            prev = p;
        }

        public LinkedListDeque() {
            size = 0;
            sentil = new Node(null, null, null);
            sentinel.next = sentinel;
            sentinel.prev = sentinel;
        }

        public void addFirst(T item) {
            size = size + 1;
            if (size == 1) {
                sentinel.next = new Node(item, sentinel, sentinel);
                sentinel.prev = sentinel.next;
            } else {
                sentinel.next = new Node(item, sentinel, sentinel.next);
                sentinel.next.next.prev = sentinel.next;
            }
        }


        public void addLast(T item) {
            size = size + 1;
            if (size == 1) {
                sentinel.prev = new Node(item, sentinel, sentinel);
                sentinel.next = sentinel.prev;
            } else {
                sentinel.prev = new node(item, sentinel.prev, sentinel);
                sentinel.prev.prev.next = sentinel.prev;
            }
        }

        public boolean isEmpty() {
            if (size == 0) {
                return true;
            } return false;
        }

        public int size() {
            return size;
        }

        public void printDeque() {
            IntNode placeholder = sentinel.next;
            whlie (placeholder.item != sentinel.item) {
                System.out.println(placeholder.item);
                System.out.println(" ");
                placeholder = placeholder.next;
            }
        }

        public T removeFirst() {
            if (size != 0) {
                size = size -  1;
                T firstNodeRemoved = sentinel.next.item;
                sentinel.next.next.prev = sentinel;
                sentinel.next = sentinel.next.next;
                return firstNodeRemoved;
            } if (size == 1) {
                T sizeEqualsOne = sentinel.next.item;
                sentinel.next = sentinel;
                sentinel.prev = sentinel;
                return sizeEqualsOne;
            } else  if (size == 0) {
                return null;
            }

        }

        public T removeLast() {
            if (size == 0) {
                return null;
            } else if (size == 1) {
                size = size - 1;
                T lastNodeRemoved = sentinel.next.item;
                sentinel.prev.prev.next = sentinel;
                sentinel.prev = sentinel;
                return lastNodeRemoved;
            } else if (size != 0) {
                size = size - 1;
                T lastNodeRemoved2 = sentinel.prev.item;
                sentinel.prev.prev.next = sentinel;
                sentinel.prev = sentinel.prev.prev;
                return lastNodeRemoved2;
            }

        }

        public T get(int index) {
            if (index >= size) {
                return null;
            } else if (index == 0) {
                return sentinel.next.item;
            } else {
                IntNode position = sentinel.next;
                for (int i = index; i > 0; i - 1) {
                    position = position.next;
                }
                return position.item;
            }
        }
/* try to figure this one out
        public T getRecursive(int index) {
            if (index >= size) {
                return null;
            } if (index == 0);
            }
        }


    }
}

 */