package ngordnet.main;
import java.util.*;

public class Graph<T> {
    // try to find the code for an adjacency list so it's easier
    // looks more like a hashmap!
    private int numVertices;
    private int size;
    private Map<T, List<T>> adjacencyList = new HashMap<>(numVertices);

    public void addVertex(T vertex) {
        adjacencyList.put(vertex, new LinkedList<T>());
    }

    public void addEdge(T to, T from, boolean direction, int size) {
        if (!adjacencyList.containsKey(to)) {
            addVertex(to);
            size += 1;
        } if (!adjacencyList.containsKey(from)) {
            addVertex(from);
            size += 1;
        }
        adjacencyList.get(from).add(to);
        if (size > numVertices) {
            resizeMap(numVertices);
        }
    }

    public void resizeMap(int numVertices) {
        if (size > numVertices) {
            adjacencyList = new HashMap<>(size);
        }

    }
}
