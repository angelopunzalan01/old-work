package ngordnet.main;

import java.util.*;

public class WordNet {
    private Graph graph;
    private int numVertices;




    public WordNet() {
        //build the graph
        graph = new Graph();
        //add all the edges
        //parse them out from data files (hyponyms11 and synset11)

    }

}
