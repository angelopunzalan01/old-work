package timingtest;
import edu.princeton.cs.algs4.Stopwatch;

/**
 * Created by hug.
 */
public class TimeSLList {
    private static void printTimingTable(AList<Integer> Ns, AList<Double> times, AList<Integer> opCounts) {
        System.out.printf("%12s %12s %12s %12s\n", "N", "time (s)", "# ops", "microsec/op");
        System.out.printf("------------------------------------------------------------\n");
        for (int i = 0; i < Ns.size(); i += 1) {
            int N = Ns.get(i);
            double time = times.get(i);
            int opCount = opCounts.get(i);
            double timePerOp = time / opCount * 1e6;
            System.out.printf("%12d %12.2f %12d %12.2f\n", N, time, opCount, timePerOp);
        }
    }

    public static void main(String[] args) {
        timeGetLast(100);
    }

    public static void timeGetLast(int M) {
        SLList newList = new SLList<Integer>();
        SLList ops = new SLList<Integer>(M);
        int N = 0;
        while (N < 100) {
            newList.addLast(N);
            N += 1;
        }

        SLList timeTaken = new SLList<Double>();
        Stopwatch times = new Stopwatch();
        timeTaken.addLast(times);

        int z = 0;
        while (z < M) {
            newList.getLast();
            z += 1;

        AList numberNs = new AList<Integer>();
        AList timeNeeded = new AList<Double>();
        AList opsUsed = new AList<Integer>();


        }



    }

}
