package hw2;

public class PercolationStats {
    public PercolationStats(int N, int T, PercolationFactory pf) {

    }

    public double mean() {

    }

    public double stddev() {

    }

    public double confidenceLow() {

    }

    public double confidenceHigh() {

    }


}
