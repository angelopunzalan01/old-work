package hw2;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation extends WeightedQuickUnionUF {
    private int size;
    public int N;
    private int imaginaryTopNode;
    private int imaginaryBottomNode;
    public int[][] percolationGrid = new int[N][N];

    public Percolation(int N) {
        /* create percolation grid with size N */
        int[][] percolationGrid = new int[N][N];
        for (int i = 0; i <= N; i++) {
            for (int j = 0; j <= N; j++) {
                percolationGrid[i][j] = 0;
            }
        }
    }

    public int To1DArray(int row, int col) {
        /* Turns 2D Array coordinates into 1 int, logic taken from Stack Overflow */
        return row * N + col;
    }

    public void unionTopNode() {
        /* unions top row with invisible top node, aka where the water starts */
        imaginaryTopNode = 999;
        for (int i = 0; i <= N; i += 1) {
            union(To1DArray(0, i), imaginaryTopNode);
        }
    }

    public void unionBottomNode() {
        /* unions bottom row with invisible bottom node, aka where water ends */
        imaginaryBottomNode = 998;
        for (int j = 0; j <= N; j+= 1) {
            union(To1DArray(N, j), imaginaryBottomNode);
        }
    }

    public void open(int row, int col) {
        /* opens a specific point in the percolation grid */
        if (percolationGrid[row][col] != 1) {
            percolationGrid[row][col] = 1;
            size += 1;
        }
    }


    public boolean isOpen(int row, int col) {
        /* checks if specific point in percolation grid is open */
        if (percolationGrid[row][col] == 1) {
            return true;
        } else {
            return false;
        }
    }

    public void unionize(int row, int col, int targetRow, int targetCol) {
        if ((isOpen(row, col) == true) && (isOpen(targetRow, targetCol) == true)) {
            union(To1DArray(row, col), To1DArray(targetRow, targetCol));
        }
    }
    public boolean isFull(int row, int col) {
        if (connected(To1DArray(row, col), imaginaryTopNode) == true) {
            return true;
        } else {
            return false;
        }
    }

    public int numberOfOpenSites() {
        return size;
    }



    public boolean percolates() {
        if (connected(imaginaryBottomNode, imaginaryTopNode) == true) {
            return true;
        } else {
            return false;
        }
    }


}
