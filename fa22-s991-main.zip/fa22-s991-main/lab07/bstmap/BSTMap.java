package bstmap;
import java.util.Iterator;
import java.util.Set;
public class BSTMap<K extends Comparable<K>, V> implements Map61B<K, V> {

    private int treeSize = 0;
    private treeNode treeRoot;


    private class treeNode {
        public treeNode left = null;
        private treeNode right = null;
        private treeNode parent = null;
        private treeNode treeRoot = null;
        private K key;
        private V value;
        public treeNode(K key, V value) {
            key = key;
            value = value;
        }

    }

    public treeNode findNode(treeNode treeNode, K key) {
        /* helper method to find specific node */
        if (treeNode == null) {
            return null;
        } else if (treeNode.key == null) {
            return null;
        } else if (treeNode.key.compareTo(key) < 0) {
            return findNode(treeNode.left, key);
        } else {
            return findNode(treeNode.right, key);
        }
    }
    @Override
    public void clear() {
        /* sets everything to null and of size 0 */
        treeSize = 0;
        treeRoot = null;

    }
    @Override
    public boolean containsKey(K key) {
        if (treeRoot == null) {
            return false;
        } else if (treeRoot.key == null) {
            return false;
        } else {
            treeNode treeNode = findNode(treeRoot, key);
            return treeNode != null;
        }

    }

    @Override
    public V get(K key) {
        treeNode treeNode = findNode(treeRoot, key);
        if (treeNode == null) {
            return null;
        } else {
            return treeNode.value;
        }
    }

    @Override
    public int size() {
        if (treeRoot == null) {
            return 0;
        } else {
            return treeSize;
        }
    }

    @Override
    public void put(K key, V value) {
        treeRoot = putHelper(treeRoot, key, value);

    }

    private treeNode putHelper(treeNode treeNode, K key, V value) {
        /* helper function for the put method */
        if (treeNode == null) {
            treeSize+= 1;
            return new treeNode(key, value);
        } else if (treeNode.key.compareTo(key) == 0) {
            treeNode.key = key;
            treeNode.value = value;
            return treeNode;
        } else if (treeNode.key.compareTo(key) < 0) {
            treeNode newTreeNode = putHelper(treeNode.left, key, value);
            newTreeNode.parent = treeNode;
            treeNode.left = newTreeNode;
            return treeNode;
        } else if (treeNode.key.compareTo(key) > 0) {
            treeNode newTreeNode = putHelper(treeNode.right, key, value);
            newTreeNode.parent = treeNode;
            treeNode.right = newTreeNode;
            return treeNode;
        }
        return treeNode;
    }

    @Override
    public Set<K> keySet() {
        throw new UnsupportedOperationException("This is not a method to use");
    }

    @Override
    public V remove(K key) {
        throw new UnsupportedOperationException("This is not a method to use");
    }

    @Override
    public V remove(K key, V value) {
        throw new UnsupportedOperationException("This is not a method to use");
    }


    @Override
    public Iterator<K> iterator() {
        throw new UnsupportedOperationException("This is not a method to use");
    }
}