package ngordnet.ngrams;

import com.sun.source.tree.Tree;

import java.util.*;

/** An object for mapping a year number (e.g. 1996) to numerical data. Provides
 *  utility methods useful for data analysis.
 *  @author Josh Hug
 */
public class TimeSeries extends TreeMap<Integer, Double> {
    /** Constructs a new empty TimeSeries. */
    public TimeSeries() {
        super();
    }

    /** Creates a copy of TS, but only between STARTYEAR and ENDYEAR,
     *  inclusive of both end points. */
    public TimeSeries(TimeSeries ts, int startYear, int endYear) {
        super();
        for (Integer year : ts.keySet()) {
            if (year >= startYear && year <= endYear) {
                this.put(year, ts.get(year));
            }
        }
    }

    /** Returns all years for this TimeSeries (in any order). */
    public List<Integer> years() {
        ArrayList<Integer> yearsCollection = new ArrayList<Integer>(this.keySet());
        return yearsCollection;
    }

    /** Returns all data for this TimeSeries (in any order).
     *  Must be in the same order as years(). */
    public List<Double> data() {
        ArrayList<Double> valuesCollection = new ArrayList<Double>(this.values());
        return valuesCollection;
    }

    /** Returns the yearwise sum of this TimeSeries with the given TS. In other words, for
     *  each year, sum the data from this TimeSeries with the data from TS. Should return a
     *  new TimeSeries (does not modify this TimeSeries). */
    public TimeSeries plus(TimeSeries ts) {
        /* creates empty TimeSeries to store answers in*/
        TimeSeries sumTimeSeries = new TimeSeries();
        Set<Integer> yearsDisplay = new HashSet<>(this.keySet());
        yearsDisplay.addAll(ts.keySet());
        for (int years : yearsDisplay) {
            double sum = 0;
            if (this.containsKey(years)) {
                sum += this.get(years).doubleValue();
            }
            if (ts.containsKey(years)) {
                sum += this.get(years).doubleValue();
            }
            sumTimeSeries.put(years, sum);
        }
        return sumTimeSeries;
    }

     /** Returns the quotient of the value for each year this TimeSeries divided by the
      *  value for the same year in TS. If TS is missing a year that exists in this TimeSeries,
      *  throw an IllegalArgumentException. If TS has a year that is not in this TimeSeries, ignore it.
      *  Should return a new TimeSeries (does not modify this TimeSeries). */
     public TimeSeries dividedBy(TimeSeries ts) {
         /* creates empty TimeSeries to store answers in */
         TimeSeries answers = new TimeSeries();
         double values;
         for (Integer year: this.keySet()) {
             if (!ts.keySet().contains(year)) {
                 throw new IllegalArgumentException("Years don't match ):");
             } else {
                 values = this.get(year).doubleValue() / ts.get(year).doubleValue();
                 answers.put(year, values);
             }
         }
         return answers;
    }
}
